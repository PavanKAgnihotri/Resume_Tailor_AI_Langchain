import time
import google.generativeai as genai

genai.configure(api_key="GOOGLE_API_KEY")
llm = genai.GenerativeModel("gemini-1.5-flash")

def build_prompt(jd, resume, links):
    links_str = "\n".join([f"{t}: {u}" for t, u in links]) if links else ""
    return f"""
You are rewriting a resume bullet point to align with a job description.

Job Description:
{jd}

Resume Bullet:
{resume}

Relevant Links:
{links_str}

Rewrite the resume bullet point to match the job, in natural, modern language. Return only one bullet point.
"""

def rewriter_node(state):
    updated_bullets = []
    for match_group in state["matches"]:
        jd = match_group["jd_chunk"]
        for match in match_group["top_resume_matches"]:
            prompt = build_prompt(jd, match["resume_chunk"], match["links"])
            try:
                result = llm.generate_content(prompt)
                updated_bullets.append(result.text.strip())
                time.sleep(1)
            except Exception as e:
                print("LLM Error:", e)
                updated_bullets.append(match["resume_chunk"])
    state["rewritten_bullets"] = updated_bullets
    return state
