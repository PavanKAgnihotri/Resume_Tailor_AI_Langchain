import numpy as np

def matcher_node(state):
    jd_docs = state["jd_docs"]
    resume_docs = state["resume_docs"]
    jd_vecs = state["jd_vectors"]
    resume_vecs = state["resume_vectors"]

    sim_matrix = np.dot(jd_vecs, resume_vecs.T)
    matches = []

    for i, jd_doc in enumerate(jd_docs):
        sims = sim_matrix[i]
        top_indices = np.argsort(sims)[::-1][:3]
        top_matches = []
        for idx in top_indices:
            top_matches.append({
                "resume_chunk": resume_docs[idx].page_content,
                "similarity": float(sims[idx]),
                "links": resume_docs[idx].metadata.get("links", [])
            })
        matches.append({"jd_chunk": jd_doc.page_content, "top_resume_matches": top_matches})

    state["matches"] = matches
    return state
