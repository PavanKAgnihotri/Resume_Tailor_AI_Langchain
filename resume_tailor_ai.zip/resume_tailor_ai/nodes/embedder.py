from sklearn.preprocessing import normalize
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings

GOOGLE_API_KEY = "API-KEY"

def embedder_node(state):
    embedding_model = GoogleGenerativeAIEmbeddings(model="models/embedding-001", google_api_key=GOOGLE_API_KEY)

    # Chunk resume text
    resume_text = state["resume_raw"]["text"]
    links = state["resume_raw"]["links"]
    splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=100)
    resume_docs = splitter.create_documents([resume_text])
    for doc in resume_docs:
        doc.metadata["links"] = links

    # Embed
    jd_docs = state["jd_docs"]
    resume_vecs = normalize(embedding_model.embed_documents([d.page_content for d in resume_docs]), axis=1)
    jd_vecs = normalize(embedding_model.embed_documents([d.page_content for d in jd_docs]), axis=1)

    state["resume_docs"] = resume_docs
    state["resume_vectors"] = resume_vecs
    state["jd_vectors"] = jd_vecs
    return state
