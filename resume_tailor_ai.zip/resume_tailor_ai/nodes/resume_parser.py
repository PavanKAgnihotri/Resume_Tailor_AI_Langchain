from fitz import open as fitz_open
import pdfplumber

def extract_text_and_links(pdf_path):
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"

    links = []
    doc = fitz_open(pdf_path)
    for page_num in range(len(doc)):
        page = doc[page_num]
        for link in page.get_links():
            if link['uri']:
                rect = link['from']
                try:
                    text_label = page.get_textbox(rect).strip()
                    links.append((text_label, link['uri']))
                except:
                    continue
    return {"text": text.strip(), "links": links}

def resume_parser_node(state):
    resume_path = state["resume_path"]
    resume_data = extract_text_and_links(resume_path)
    state["resume_raw"] = resume_data
    return state
