#pip install langgraph langchain langchain-google-genai google-generativeai weasyprint jinja2 faiss-cpu
from langgraph.graph import StateGraph
from nodes.resume_parser import resume_parser_node
from nodes.jd_parser import jd_parser_node
from nodes.embedder import embedder_node
from nodes.matcher import matcher_node
from nodes.rewriter import rewriter_node

graph = StateGraph()

graph.add_node("parse_resume", resume_parser_node)
graph.add_node("parse_jd", jd_parser_node)
graph.add_node("embed", embedder_node)
graph.add_node("match", matcher_node)
graph.add_node("rewrite", rewriter_node)


graph.set_entry_point("parse_resume")
graph.add_edge("parse_resume", "parse_jd")
graph.add_edge("parse_jd", "embed")
graph.add_edge("embed", "match")
graph.add_edge("match", "rewrite")
graph.set_finish_point("rewrite")

app = graph.compile()

# === RUN GRAPH ===
if __name__ == "__main__":
    state = {
        "resume_path": "Engineering_Sample_Resume1.pdf",
        "jd_text": """We are seeking a Mechanical Engineering Intern familiar with CAD modeling, SolidWorks, and MATLAB. Hands-on hardware disassembly experience is a plus."""
    }

    final_state = app.invoke(state)
