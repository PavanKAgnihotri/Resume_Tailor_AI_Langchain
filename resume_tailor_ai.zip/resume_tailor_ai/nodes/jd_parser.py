from langchain_text_splitters import RecursiveCharacterTextSplitter

def jd_parser_node(state):
    jd_text = state["jd_text"]
    splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=100)
    jd_docs = splitter.create_documents([jd_text])
    state["jd_docs"] = jd_docs
    return state
